<?php
require_once __DIR__ . '/config.php';
$user = require_customer(); $userId = (int)$user['id'];
$stmt = $conn->prepare('SELECT id, total_amount, payment_status, order_status, created_at, address FROM orders WHERE user_id = ? ORDER BY created_at DESC'); $stmt->bind_param('i', $userId); $stmt->execute(); $orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$pageTitle = 'Order history';
require __DIR__ . '/includes/header.php';
?>
<div class="page-intro compact"><p class="eyebrow">YOUR PURCHASES</p><h1>Order history.</h1><p>Everything you’ve picked up from VoltCart, in one place.</p></div>
<?php if ($orders): ?><div class="order-list"><?php foreach ($orders as $order): ?><article class="order-card"><div class="order-heading"><div><p class="eyebrow">ORDER #<?= (int)$order['id'] ?></p><h2><?= date('M j, Y', strtotime($order['created_at'])) ?></h2></div><span class="status-badge status-<?= e($order['order_status']) ?>"><?= e(ucfirst($order['order_status'])) ?></span></div><div class="order-meta"><span><?= e($order['payment_status'] === 'paid' ? 'Paid' : ucfirst($order['payment_status'])) ?></span><strong><?= money((float)$order['total_amount']) ?></strong><a class="text-link" href="<?= url('reorder.php?order=' . (int)$order['id']) ?>">Reorder →</a></div><p class="muted order-address"><?= nl2br(e($order['address'])) ?></p></article><?php endforeach; ?></div><?php else: ?><div class="empty-state"><span class="empty-icon">↗</span><h2>No orders yet.</h2><p>Your first upgrade is a few clicks away.</p><a class="button button-small" href="<?= url('products.php') ?>">Browse products</a></div><?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
