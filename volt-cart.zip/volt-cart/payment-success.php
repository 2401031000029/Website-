<?php
require_once __DIR__ . '/config.php';
$user = require_customer(); $orderId = filter_input(INPUT_GET, 'order', FILTER_VALIDATE_INT);
$stmt = $conn->prepare('SELECT id, total_amount, created_at FROM orders WHERE id = ? AND user_id = ? LIMIT 1'); $stmt->bind_param('ii', $orderId, $user['id']); $stmt->execute(); $order = $stmt->get_result()->fetch_assoc();
if (!$order) redirect(url('orders.php'));
$pageTitle = 'Order confirmed';
require __DIR__ . '/includes/header.php';
?>
<div class="success-shell"><div class="success-mark">✓</div><p class="eyebrow">PAYMENT SUCCESSFUL</p><h1>Order <?= (int)$order['id'] ?> is on its way.</h1><p>Your simulated payment went through. We’ll keep your order details ready in your account.</p><div class="success-total"><span>Total paid</span><strong><?= money((float)$order['total_amount']) ?></strong></div><div class="hero-actions"><a class="button" href="<?= url('orders.php') ?>">View order history</a><a class="text-link" href="<?= url('products.php') ?>">Keep shopping →</a></div></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
