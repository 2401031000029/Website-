<?php
require_once __DIR__ . '/../config.php';
if (!empty($_SESSION['admin_id'])) redirect(url('admin/index.php'));
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf(); $email = strtolower(trim($_POST['email'] ?? '')); $password = $_POST['password'] ?? '';
    $stmt = $conn->prepare("SELECT id, name, password, status FROM users WHERE email = ? AND role = 'admin' LIMIT 1"); $stmt->bind_param('s', $email); $stmt->execute(); $admin = $stmt->get_result()->fetch_assoc();
    if ($admin && $admin['status'] === 'active' && password_verify($password, $admin['password'])) { $_SESSION['admin_id'] = (int)$admin['id']; redirect(url('admin/index.php')); }
    $error = 'Admin email or password is incorrect.';
}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Admin sign in · VoltCart</title><link rel="stylesheet" href="<?= asset('assets/style.css') ?>"></head><body class="admin-body"><div class="accent-line"></div><div class="auth-shell"><div class="auth-card"><a class="brand" href="<?= url('index.php') ?>"><span class="brand-mark">V</span><span>Volt<span class="brand-accent">Cart</span> <small>ADMIN</small></span></a><p class="eyebrow">CONTROL ROOM</p><h1>Admin sign in.</h1><p class="muted">Manage the VoltCart catalog, customers, and orders.</p><?php if ($error): ?><div class="flash flash-error"><?= e($error) ?></div><?php endif; ?><form method="post" class="form-stack"><?= csrf_field() ?><label>Email<input type="email" name="email" required></label><label>Password<input type="password" name="password" required></label><button class="button" type="submit">Enter dashboard</button></form><p class="auth-switch"><a href="<?= url('admin/setup.php') ?>">First-time setup</a></p></div></div></body></html>
