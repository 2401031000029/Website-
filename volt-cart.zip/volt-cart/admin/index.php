<?php
require_once __DIR__ . '/../config.php';
$stats = [
    ['Users', "SELECT COUNT(*) total FROM users WHERE role = 'customer'", 'admin/users.php'],
    ['Products', "SELECT COUNT(*) total FROM product", 'admin/products.php'],
    ['Categories', "SELECT COUNT(*) total FROM category", 'admin/categories.php'],
    ['Orders', "SELECT COUNT(*) total FROM orders", 'admin/orders.php'],
];
$revenue = (float)$conn->query("SELECT COALESCE(SUM(total_amount),0) total FROM orders WHERE payment_status = 'paid'")->fetch_assoc()['total'];
$recent = $conn->query("SELECT o.id, o.total_amount, o.order_status, o.created_at, u.name FROM orders o JOIN users u ON u.id = o.user_id ORDER BY o.created_at DESC LIMIT 6")->fetch_all(MYSQLI_ASSOC);
$adminPageTitle = 'Dashboard';
require __DIR__ . '/../includes/admin-header.php';
?>
<div class="admin-nav"><a class="active" href="<?= url('admin/index.php') ?>">Dashboard</a><a href="<?= url('admin/users.php') ?>">Users</a><a href="<?= url('admin/categories.php') ?>">Categories</a><a href="<?= url('admin/products.php') ?>">Products</a><a href="<?= url('admin/orders.php') ?>">Orders</a></div>
<div class="page-intro compact"><p class="eyebrow">OVERVIEW</p><h1>Good morning, admin.</h1><p>Here’s what’s happening across VoltCart.</p></div>
<div class="admin-stats"><?php foreach ($stats as [$label, $query, $link]): $value = (int)$conn->query($query)->fetch_assoc()['total']; ?><a class="admin-stat" href="<?= url($link) ?>"><span><?= e($label) ?></span><strong><?= $value ?></strong><small>Manage →</small></a><?php endforeach; ?><div class="admin-stat revenue"><span>Revenue</span><strong><?= money($revenue) ?></strong><small>Paid orders</small></div></div>
<section class="admin-table-card"><div class="section-heading"><div><p class="eyebrow">RECENT ACTIVITY</p><h2>Latest orders</h2></div><a class="text-link" href="<?= url('admin/orders.php') ?>">View all →</a></div><div class="table-wrap"><table><thead><tr><th>Order</th><th>Customer</th><th>Date</th><th>Status</th><th>Total</th></tr></thead><tbody><?php foreach ($recent as $order): ?><tr><td>#<?= (int)$order['id'] ?></td><td><?= e($order['name']) ?></td><td><?= date('M j, Y', strtotime($order['created_at'])) ?></td><td><span class="status-badge status-<?= e($order['order_status']) ?>"><?= e(ucfirst($order['order_status'])) ?></span></td><td><?= money((float)$order['total_amount']) ?></td></tr><?php endforeach; ?></tbody></table></div></section>
<?php require __DIR__ . '/../includes/admin-footer.php'; ?>
