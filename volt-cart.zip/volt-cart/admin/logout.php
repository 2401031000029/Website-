<?php
require_once __DIR__ . '/../config.php';
unset($_SESSION['admin_id']);
redirect(url('admin/login.php'));
