<?php
require_once __DIR__ . '/../config.php';
$editUser = null; $error = '';
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit']; $stmt = $conn->prepare("SELECT id, name, email, phone, address FROM users WHERE id = ? AND role = 'customer'");
    $stmt->bind_param('i', $id); $stmt->execute(); $editUser = $stmt->get_result()->fetch_assoc();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf(); $id = (int)($_POST['id'] ?? 0); $action = $_POST['action'] ?? '';
    if ($action === 'toggle') { $stmt = $conn->prepare("UPDATE users SET status = IF(status = 'active', 'blocked', 'active') WHERE id = ? AND role = 'customer'"); $stmt->bind_param('i', $id); $stmt->execute(); flash('success', 'User status updated.'); redirect(url('admin/users.php')); }
    if ($action === 'delete') { $stmt = $conn->prepare("DELETE FROM users WHERE id = ? AND role = 'customer'"); $stmt->bind_param('i', $id); $stmt->execute(); flash('success', 'User deleted.'); redirect(url('admin/users.php')); }
    if ($action === 'save') {
        $name = trim($_POST['name'] ?? ''); $email = strtolower(trim($_POST['email'] ?? '')); $phone = trim($_POST['phone'] ?? ''); $address = trim($_POST['address'] ?? ''); $password = $_POST['password'] ?? '';
        if (!$name || !filter_var($email, FILTER_VALIDATE_EMAIL) || (!$id && strlen($password) < 6)) $error = 'Name and a valid email are required; new users need a 6+ character password.';
        else {
            if ($id) {
                if ($password) { $hash = password_hash($password, PASSWORD_DEFAULT); $stmt = $conn->prepare("UPDATE users SET name=?, email=?, phone=?, address=?, password=? WHERE id=? AND role='customer'"); $stmt->bind_param('sssssi', $name, $email, $phone, $address, $hash, $id); }
                else { $stmt = $conn->prepare("UPDATE users SET name=?, email=?, phone=?, address=? WHERE id=? AND role='customer'"); $stmt->bind_param('ssssi', $name, $email, $phone, $address, $id); }
            } else { $hash = password_hash($password, PASSWORD_DEFAULT); $stmt = $conn->prepare("INSERT INTO users (name, email, phone, address, password, role) VALUES (?, ?, ?, ?, ?, 'customer')"); $stmt->bind_param('sssss', $name, $email, $phone, $address, $hash); }
            if (!$stmt->execute()) $error = 'Could not save user. Check that the email is not already in use.';
            else { flash('success', 'User saved.'); redirect(url('admin/users.php')); }
        }
    }
}
$users = $conn->query("SELECT id, name, email, phone, status, created_at FROM users WHERE role = 'customer' ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);
$adminPageTitle = 'Manage users'; require __DIR__ . '/../includes/admin-header.php';
?>
<div class="admin-nav"><a href="<?= url('admin/index.php') ?>">Dashboard</a><a class="active" href="<?= url('admin/users.php') ?>">Users</a><a href="<?= url('admin/categories.php') ?>">Categories</a><a href="<?= url('admin/products.php') ?>">Products</a><a href="<?= url('admin/orders.php') ?>">Orders</a></div><div class="page-intro compact"><p class="eyebrow">CUSTOMERS</p><h1>Manage users.</h1><p>Keep account access and customer details up to date.</p></div><div class="admin-form-row"><section class="form-card"><h2><?= $editUser ? 'Edit user' : 'Add user' ?></h2><?php if ($error): ?><div class="flash flash-error"><?= e($error) ?></div><?php endif; ?><form method="post" class="form-stack"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)($editUser['id'] ?? 0) ?>"><label>Name<input name="name" required value="<?= e($editUser['name'] ?? '') ?>"></label><label>Email<input type="email" name="email" required value="<?= e($editUser['email'] ?? '') ?>"></label><label>Phone<input name="phone" value="<?= e($editUser['phone'] ?? '') ?>"></label><label>Address<textarea name="address" rows="3"><?= e($editUser['address'] ?? '') ?></textarea></label><label>Password <span class="label-hint"><?= $editUser ? '(leave blank to keep current)' : '(required)' ?></span><input type="password" name="password" <?= $editUser ? '' : 'required' ?> minlength="6"></label><div class="form-actions"><a href="<?= url('admin/users.php') ?>">Clear</a><button class="button" name="action" value="save" type="submit"><?= $editUser ? 'Save changes' : 'Add user' ?></button></div></form></section><section class="admin-table-card flex-grow"><div class="table-wrap"><table><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Joined</th><th>Status</th><th>Actions</th></tr></thead><tbody><?php foreach ($users as $user): ?><tr><td><strong><?= e($user['name']) ?></strong></td><td><?= e($user['email']) ?></td><td><?= e($user['phone']) ?></td><td><?= date('M j, Y', strtotime($user['created_at'])) ?></td><td><span class="status-badge status-<?= e($user['status']) ?>"><?= e(ucfirst($user['status'])) ?></span></td><td><form method="post" class="inline-form"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$user['id'] ?>"><a class="text-button" href="<?= url('admin/users.php?edit=' . (int)$user['id']) ?>">Edit</a><button class="text-button" name="action" value="toggle"><?= $user['status'] === 'active' ? 'Block' : 'Unblock' ?></button><button class="text-button danger" name="action" value="delete">Delete</button></form></td></tr><?php endforeach; ?></tbody></table></div></section></div>
<?php require __DIR__ . '/../includes/admin-footer.php'; ?>