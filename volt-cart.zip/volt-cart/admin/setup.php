<?php
require_once __DIR__ . '/../config.php';
$count = (int)$conn->query("SELECT COUNT(*) AS total FROM users WHERE role = 'admin'")->fetch_assoc()['total']; $error = '';
if ($count > 0) exit('Admin setup is already complete. <a href="../admin/login.php">Go to admin login</a>.');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf(); $name = trim($_POST['name'] ?? ''); $email = strtolower(trim($_POST['email'] ?? '')); $password = $_POST['password'] ?? '';
    if (!$name || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 6) $error = 'Enter a name, valid email, and password of at least 6 characters.';
    else { $hash = password_hash($password, PASSWORD_DEFAULT); $stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'admin')"); $stmt->bind_param('sss', $name, $email, $hash); $stmt->execute(); flash('success', 'Admin account created.'); redirect(url('admin/login.php')); }
}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Admin setup · VoltCart</title><link rel="stylesheet" href="<?= asset('assets/style.css') ?>"></head><body class="admin-body"><div class="accent-line"></div><div class="auth-shell"><div class="auth-card"><p class="eyebrow">ONE-TIME SETUP</p><h1>Create the first admin.</h1><p class="muted">Remove or protect this file after setup in a public demo.</p><?php if ($error): ?><div class="flash flash-error"><?= e($error) ?></div><?php endif; ?><form method="post" class="form-stack"><?= csrf_field() ?><label>Name<input name="name" required></label><label>Email<input type="email" name="email" required></label><label>Password<input type="password" name="password" minlength="6" required></label><button class="button" type="submit">Create admin account</button></form></div></div></body></html>
