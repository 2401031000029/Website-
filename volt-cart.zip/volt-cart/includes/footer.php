</div>
</main>
<footer class="site-footer">
    <div class="container footer-grid">
        <div><a class="brand" href="<?= url('index.php') ?>"><span class="brand-mark">V</span><span>Volt<span class="brand-accent">Cart</span></span></a><p class="muted">Smart tech. Better living.</p></div>
        <div><h4>Shop</h4><a href="<?= url('products.php') ?>">All products</a><a href="<?= url('categories.php') ?>">Categories</a><a href="<?= url('wishlist.php') ?>">Wishlist</a></div>
        <div><h4>Account</h4><a href="<?= url('profile.php') ?>">My profile</a><a href="<?= url('orders.php') ?>">Order history</a><a href="<?= url('forgot-password.php') ?>">Forgot password</a></div>
        <div><h4>Need help?</h4><p class="muted">Mon–Fri, 9am–6pm<br>support@voltcart.test</p></div>
    </div>
    <div class="container footer-bottom"><span>© <?= date('Y') ?> VoltCart</span><span>Built for everyday upgrades.</span></div>
</footer>
</body>
</html>
