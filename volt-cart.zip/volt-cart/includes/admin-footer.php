</div></main>
<footer class="site-footer"><div class="container footer-bottom"><span>VoltCart admin console</span><span>Keep inventory accurate.</span></div></footer>
</body>
</html>
