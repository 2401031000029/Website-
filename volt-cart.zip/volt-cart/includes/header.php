<?php
require_once __DIR__ . '/../config.php';
$currentUser = customer();
$flashes = get_flashes();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle ?? SITE_NAME) ?> · <?= SITE_NAME ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= asset('assets/style.css') ?>">
</head>
<body>
<div class="accent-line"></div>
<header class="site-header">
    <div class="container nav-wrap">
        <a class="brand" href="<?= url('index.php') ?>"><span class="brand-mark">V</span><span>Volt<span class="brand-accent">Cart</span></span></a>
        <form class="search" action="<?= url('products.php') ?>" method="get">
            <input name="q" type="search" value="<?= e($_GET['q'] ?? '') ?>" placeholder="Search devices, accessories...">
            <button type="submit" aria-label="Search">Search</button>
        </form>
        <nav class="nav-actions">
            <a href="<?= url('wishlist.php') ?>" class="nav-link">Wishlist</a>
            <a href="<?= url('cart.php') ?>" class="nav-link cart-link">Cart <span class="count"><?= cart_count() ?></span></a>
            <?php if ($currentUser): ?>
                <a href="<?= url('profile.php') ?>" class="avatar-link"><span class="avatar"><?= $currentUser['profile_pic'] ? '<img src="' . asset($currentUser['profile_pic']) . '" alt="">' : e(strtoupper(substr($currentUser['name'], 0, 1))) ?></span><span class="hide-small"><?= e($currentUser['name']) ?></span></a>
            <?php else: ?>
                <a class="button button-small button-outline" href="<?= url('login.php') ?>">Sign in</a>
            <?php endif; ?>
        </nav>
    </div>
</header>
<main class="site-main">
<div class="container">
<?php foreach ($flashes as $flash): ?>
    <div class="flash flash-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
<?php endforeach; ?>
