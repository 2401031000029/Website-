<?php
require_once __DIR__ . '/../config.php';
if (empty($_SESSION['admin_id'])) redirect(url('admin/login.php'));
$adminPageTitle = $adminPageTitle ?? 'Admin';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($adminPageTitle) ?> · VoltCart Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= asset('assets/style.css') ?>">
</head>
<body class="admin-body">
<div class="accent-line"></div>
<header class="admin-header"><div class="container nav-wrap"><a class="brand" href="<?= url('admin/index.php') ?>"><span class="brand-mark">V</span><span>Volt<span class="brand-accent">Cart</span> <small>ADMIN</small></span></a><nav class="nav-actions"><a class="nav-link" href="<?= url('index.php') ?>">View store</a><a class="button button-small button-outline" href="<?= url('admin/logout.php') ?>">Log out</a></nav></div></header>
<main class="site-main"><div class="container">
<?php foreach (get_flashes() as $flash): ?><div class="flash flash-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endforeach; ?>
