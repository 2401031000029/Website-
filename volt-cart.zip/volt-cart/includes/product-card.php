<?php
$productImage = $product['image'] ? asset($product['image']) : asset('assets/product-placeholder.svg');
?>
<article class="product-card">
    <a class="product-image" href="<?= url('product.php?id=' . (int)$product['id']) ?>"><img src="<?= e($productImage) ?>" alt="<?= e($product['name']) ?>"><span class="image-glow"></span></a>
    <div class="product-card-body">
        <p class="eyebrow"><?= e($product['category_name'] ?? 'Featured tech') ?></p>
        <h3><a href="<?= url('product.php?id=' . (int)$product['id']) ?>"><?= e($product['name']) ?></a></h3>
        <p class="product-summary"><?= e(mb_strimwidth($product['description'] ?? '', 0, 78, '...')) ?></p>
        <div class="product-card-bottom"><span class="price-pill"><?= money((float)$product['price']) ?></span><span class="stock-note"><?= (int)$product['stock'] > 0 ? 'In stock' : 'Sold out' ?></span></div>
    </div>
</article>
