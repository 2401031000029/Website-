<?php
require_once __DIR__ . '/config.php';
$user = require_customer(); $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = trim($_POST['name'] ?? ''); $phone = trim($_POST['phone'] ?? ''); $address = trim($_POST['address'] ?? '');
    if (!$name) $error = 'Name is required.';
    else {
        $profile = safe_upload($_FILES['profile_pic'] ?? [], 'uploads/profile', 'avatar');
        if ($profile) { $stmt = $conn->prepare('UPDATE users SET name = ?, phone = ?, address = ?, profile_pic = ? WHERE id = ?'); $stmt->bind_param('ssssi', $name, $phone, $address, $profile, $user['id']); }
        else { $stmt = $conn->prepare('UPDATE users SET name = ?, phone = ?, address = ? WHERE id = ?'); $stmt->bind_param('sssi', $name, $phone, $address, $user['id']); }
        $stmt->execute(); flash('success', 'Your profile has been updated.'); redirect(url('profile.php'));
    }
}
$pageTitle = 'My profile';
require __DIR__ . '/includes/header.php';
?>
<div class="page-intro compact"><p class="eyebrow">YOUR DETAILS</p><h1>My profile.</h1><p>Keep your delivery details current and checkout stays quick.</p></div>
<div class="settings-layout"><aside class="settings-nav"><a class="active" href="<?= url('profile.php') ?>">Profile details</a><a href="<?= url('orders.php') ?>">Order history</a><a href="<?= url('change-password.php') ?>">Change password</a><a href="<?= url('logout.php') ?>">Sign out</a></aside><section class="form-card"><?php if ($error): ?><div class="flash flash-error"><?= e($error) ?></div><?php endif; ?><form method="post" enctype="multipart/form-data" class="form-grid"><?= csrf_field() ?><div class="profile-preview"><span class="avatar avatar-large"><?= $user['profile_pic'] ? '<img src="' . asset($user['profile_pic']) . '" alt="">' : e(strtoupper(substr($user['name'], 0, 1))) ?></span><div><strong><?= e($user['name']) ?></strong><span><?= e($user['email']) ?></span></div></div><label>Full name<input name="name" value="<?= e($user['name']) ?>" required></label><label>Phone<input name="phone" value="<?= e($user['phone']) ?>"></label><label class="full">Address<textarea name="address" rows="4"><?= e($user['address']) ?></textarea></label><label class="full">Replace profile picture <span class="label-hint">(optional, max 4MB)</span><input type="file" name="profile_pic" accept="image/jpeg,image/png,image/webp"></label><div class="full form-actions"><span></span><button class="button" type="submit">Save changes</button></div></form></section></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
