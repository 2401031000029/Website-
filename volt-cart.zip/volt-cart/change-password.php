<?php
require_once __DIR__ . '/config.php';
$user = require_customer(); $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf(); $current = $_POST['current_password'] ?? ''; $new = $_POST['new_password'] ?? ''; $confirm = $_POST['confirm_password'] ?? '';
    $stmt = $conn->prepare('SELECT password FROM users WHERE id = ?'); $stmt->bind_param('i', $user['id']); $stmt->execute(); $record = $stmt->get_result()->fetch_assoc();
    if (!password_verify($current, $record['password'])) $error = 'Your current password is incorrect.';
    elseif (strlen($new) < 6) $error = 'New password must be at least 6 characters.';
    elseif ($new !== $confirm) $error = 'New passwords do not match.';
    else { $hash = password_hash($new, PASSWORD_DEFAULT); $stmt = $conn->prepare('UPDATE users SET password = ? WHERE id = ?'); $stmt->bind_param('si', $hash, $user['id']); $stmt->execute(); flash('success', 'Your password has been changed.'); redirect(url('profile.php')); }
}
$pageTitle = 'Change password';
require __DIR__ . '/includes/header.php';
?>
<div class="page-intro compact"><p class="eyebrow">ACCOUNT SECURITY</p><h1>Change password.</h1><p>Use a password you don’t reuse anywhere else.</p></div><div class="settings-layout"><aside class="settings-nav"><a href="<?= url('profile.php') ?>">Profile details</a><a href="<?= url('orders.php') ?>">Order history</a><a class="active" href="<?= url('change-password.php') ?>">Change password</a><a href="<?= url('logout.php') ?>">Sign out</a></aside><section class="form-card form-narrow"><?php if ($error): ?><div class="flash flash-error"><?= e($error) ?></div><?php endif; ?><form method="post" class="form-stack"><?= csrf_field() ?><label>Current password<input type="password" name="current_password" required></label><label>New password<input type="password" name="new_password" minlength="6" required></label><label>Confirm new password<input type="password" name="confirm_password" minlength="6" required></label><div class="form-actions"><span></span><button class="button" type="submit">Update password</button></div></form></section></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
