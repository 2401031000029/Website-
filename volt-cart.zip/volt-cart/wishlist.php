<?php
require_once __DIR__ . '/config.php';
$user = require_customer(); $userId = (int)$user['id'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf(); $productId = (int)($_POST['product_id'] ?? 0);
    $stmt = $conn->prepare('DELETE FROM wishlist WHERE user_id = ? AND product_id = ?'); $stmt->bind_param('ii', $userId, $productId); $stmt->execute();
    flash('success', 'Removed from your wishlist.'); redirect(url('wishlist.php'));
}
$stmt = $conn->prepare("SELECT p.*, c.name AS category_name FROM wishlist w JOIN product p ON p.id = w.product_id JOIN category c ON c.id = p.category_id WHERE w.user_id = ? ORDER BY w.id DESC");
$stmt->bind_param('i', $userId); $stmt->execute(); $products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$pageTitle = 'Wishlist';
require __DIR__ . '/includes/header.php';
?>
<div class="page-intro compact"><p class="eyebrow">SAVED FOR LATER</p><h1>Your wishlist.</h1><p>Keep the good ideas close until you’re ready.</p></div>
<?php if ($products): ?><div class="product-grid"><?php foreach ($products as $product): ?><div class="wishlist-wrap"><?php require __DIR__ . '/includes/product-card.php'; ?><form method="post" class="wishlist-remove"><?= csrf_field() ?><input type="hidden" name="product_id" value="<?= (int)$product['id'] ?>"><button class="remove-button" type="submit">Remove from wishlist</button></form></div><?php endforeach; ?></div><?php else: ?><div class="empty-state"><span class="empty-icon">♡</span><h2>Your wishlist is empty.</h2><p>Save products you want to revisit.</p><a class="button button-small" href="<?= url('products.php') ?>">Browse products</a></div><?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
