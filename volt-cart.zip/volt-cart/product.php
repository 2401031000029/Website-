<?php
require_once __DIR__ . '/config.php';
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) redirect(url('products.php'));
$stmt = $conn->prepare("SELECT p.*, c.name AS category_name FROM product p JOIN category c ON c.id = p.category_id WHERE p.id = ? AND p.status = 'show' LIMIT 1");
$stmt->bind_param('i', $id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();
if (!$product) { http_response_code(404); exit('Product not found.'); }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_customer();
    verify_csrf();
    $qty = max(1, min((int)($_POST['qty'] ?? 1), (int)$product['stock']));
    if ($product['stock'] < 1) { flash('error', 'This product is currently out of stock.'); redirect(url('product.php?id=' . $id)); }
    if (($_POST['action'] ?? '') === 'wishlist') {
        $stmt = $conn->prepare('INSERT IGNORE INTO wishlist (user_id, product_id) VALUES (?, ?)');
        $userId = (int)$_SESSION['customer_id']; $stmt->bind_param('ii', $userId, $id); $stmt->execute();
        flash('success', 'Added to your wishlist.'); redirect(url('wishlist.php'));
    }
    $stmt = $conn->prepare('INSERT INTO cart (user_id, product_id, qty) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE qty = LEAST(qty + VALUES(qty), ?)');
    $userId = (int)$_SESSION['customer_id']; $stock = (int)$product['stock'];
    $stmt->bind_param('iiii', $userId, $id, $qty, $stock); $stmt->execute();
    flash('success', 'Added to cart.'); redirect(url('cart.php'));
}
$pageTitle = $product['name'];
require __DIR__ . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?= url('products.php') ?>">Products</a><span>/</span><span><?= e($product['name']) ?></span></div>
<section class="detail-layout">
    <div class="detail-image"><img src="<?= e($product['image'] ? asset($product['image']) : asset('assets/product-placeholder.svg')) ?>" alt="<?= e($product['name']) ?>"></div>
    <div class="detail-copy"><p class="eyebrow"><?= e($product['category_name']) ?></p><h1><?= e($product['name']) ?></h1><div class="detail-price"><?= money((float)$product['price']) ?></div><p class="detail-description"><?= nl2br(e($product['description'])) ?></p>
        <div class="stock-status <?= (int)$product['stock'] > 0 ? 'in-stock' : 'out-stock' ?>"><span></span><?= (int)$product['stock'] > 0 ? (int)$product['stock'] . ' available now' : 'Currently out of stock' ?></div>
        <?php if ((int)$product['stock'] > 0): ?><form method="post" class="buy-form"><?= csrf_field() ?><label for="qty">Quantity</label><div class="buy-row"><input id="qty" type="number" name="qty" min="1" max="<?= (int)$product['stock'] ?>" value="1"><button class="button" name="action" value="cart" type="submit">Add to cart <span>→</span></button></div></form><?php endif; ?>
        <form method="post" class="wishlist-form"><?= csrf_field() ?><button class="button button-outline" name="action" value="wishlist" type="submit">♡ Add to wishlist</button></form>
    </div>
</section>
<section class="trust-strip"><div><strong>Fast dispatch</strong><span>Ships within 1–2 business days</span></div><div><strong>30-day returns</strong><span>Simple, no-stress returns</span></div><div><strong>Secure checkout</strong><span>Your data stays protected</span></div></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
