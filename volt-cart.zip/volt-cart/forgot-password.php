<?php
require_once __DIR__ . '/config.php';
$message = ''; $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf(); $email = strtolower(trim($_POST['email'] ?? '')); $password = $_POST['new_password'] ?? '';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 6) $error = 'Enter a valid email and a password of at least 6 characters.';
    else { $hash = password_hash($password, PASSWORD_DEFAULT); $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ? AND role = 'customer'"); $stmt->bind_param('ss', $hash, $email); $stmt->execute(); $message = 'If that account exists, the password has been updated for this demo. You can sign in now.'; }
}
$pageTitle = 'Forgot password';
require __DIR__ . '/includes/header.php';
?>
<div class="auth-shell"><div class="auth-card"><p class="eyebrow">ACCOUNT RECOVERY</p><h1>Reset your password.</h1><p class="muted">This classroom demo skips email verification so you can test the full flow.</p><?php if ($error): ?><div class="flash flash-error"><?= e($error) ?></div><?php elseif ($message): ?><div class="flash flash-success"><?= e($message) ?></div><?php endif; ?><form method="post" class="form-stack"><?= csrf_field() ?><label>Email<input type="email" name="email" required></label><label>New password<input type="password" name="new_password" minlength="6" required></label><div class="form-actions"><a href="<?= url('login.php') ?>">Back to sign in</a><button class="button" type="submit">Reset password</button></div></form></div></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
