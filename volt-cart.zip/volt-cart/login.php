<?php
require_once __DIR__ . '/config.php';
if (customer()) redirect(url('index.php'));
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = strtolower(trim($_POST['email'] ?? '')); $password = $_POST['password'] ?? '';
    $stmt = $conn->prepare("SELECT id, password, status FROM users WHERE email = ? AND role = 'customer' LIMIT 1");
    $stmt->bind_param('s', $email); $stmt->execute(); $user = $stmt->get_result()->fetch_assoc();
    if ($user && password_verify($password, $user['password']) && $user['status'] === 'active') {
        $_SESSION['customer_id'] = (int)$user['id']; flash('success', 'Welcome back.'); redirect(url('index.php'));
    }
    $error = 'Email or password is incorrect.';
}
$pageTitle = 'Sign in';
require __DIR__ . '/includes/header.php';
?>
<div class="auth-shell"><div class="auth-card"><p class="eyebrow">WELCOME BACK</p><h1>Sign in to VoltCart.</h1><p class="muted">Keep your wishlist, orders, and details in one place.</p><?php if ($error): ?><div class="flash flash-error"><?= e($error) ?></div><?php endif; ?><form method="post" class="form-stack"><?= csrf_field() ?><label>Email<input type="email" name="email" required autocomplete="email"></label><label>Password<input type="password" name="password" required autocomplete="current-password"></label><div class="form-actions"><a href="<?= url('forgot-password.php') ?>">Forgot password?</a><button class="button" type="submit">Sign in</button></div></form><p class="auth-switch">New here? <a href="<?= url('register.php') ?>">Create an account</a></p></div></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
