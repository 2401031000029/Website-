<?php
require_once __DIR__ . '/config.php';
$user = require_customer(); $orderId = filter_input(INPUT_GET, 'order', FILTER_VALIDATE_INT);
$stmt = $conn->prepare('SELECT oi.product_id, oi.qty, p.stock, p.status, p.name FROM order_items oi JOIN orders o ON o.id = oi.order_id JOIN product p ON p.id = oi.product_id WHERE oi.order_id = ? AND o.user_id = ?');
$stmt->bind_param('ii', $orderId, $user['id']); $stmt->execute(); $items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
if (!$items) { flash('error', 'Order not found.'); redirect(url('orders.php')); }
$added = 0; $skipped = [];
foreach ($items as $item) {
    if ($item['status'] !== 'show' || (int)$item['stock'] < 1) { $skipped[] = $item['name']; continue; }
    $qty = min((int)$item['qty'], (int)$item['stock']); $stmt = $conn->prepare('INSERT INTO cart (user_id, product_id, qty) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE qty = LEAST(qty + VALUES(qty), ?)');
    $stock = (int)$item['stock']; $stmt->bind_param('iiii', $user['id'], $item['product_id'], $qty, $stock); $stmt->execute(); $added++;
}
flash('success', $added . ' item(s) added to your cart.' . ($skipped ? ' Skipped: ' . implode(', ', $skipped) . '.' : ''));
redirect(url('cart.php'));
