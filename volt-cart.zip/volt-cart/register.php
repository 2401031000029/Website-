<?php
require_once __DIR__ . '/config.php';
if (customer()) redirect(url('index.php'));
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = trim($_POST['name'] ?? ''); $email = strtolower(trim($_POST['email'] ?? '')); $phone = trim($_POST['phone'] ?? ''); $address = trim($_POST['address'] ?? ''); $password = $_POST['password'] ?? '';
    if (!$name || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 6) $error = 'Enter a name, valid email, and password of at least 6 characters.';
    else {
        $stmt = $conn->prepare('SELECT id FROM users WHERE email = ? LIMIT 1'); $stmt->bind_param('s', $email); $stmt->execute();
        if ($stmt->get_result()->fetch_assoc()) $error = 'An account with that email already exists.';
        else {
            $profile = safe_upload($_FILES['profile_pic'] ?? [], 'uploads/profile', 'avatar');
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (name, email, password, phone, address, profile_pic, role) VALUES (?, ?, ?, ?, ?, ?, 'customer')");
            $stmt->bind_param('ssssss', $name, $email, $hash, $phone, $address, $profile); $stmt->execute();
            $_SESSION['customer_id'] = $conn->insert_id; flash('success', 'Your account is ready.'); redirect(url('index.php'));
        }
    }
}
$pageTitle = 'Create account';
require __DIR__ . '/includes/header.php';
?>
<div class="auth-shell"><div class="auth-card auth-card-wide"><p class="eyebrow">JOIN THE CLUB</p><h1>Create your account.</h1><p class="muted">Save products, check out faster, and see every order.</p><?php if ($error): ?><div class="flash flash-error"><?= e($error) ?></div><?php endif; ?><form method="post" enctype="multipart/form-data" class="form-grid"><?= csrf_field() ?><label>Full name<input name="name" required value="<?= e($_POST['name'] ?? '') ?>"></label><label>Email<input type="email" name="email" required value="<?= e($_POST['email'] ?? '') ?>"></label><label>Phone<input name="phone" value="<?= e($_POST['phone'] ?? '') ?>"></label><label>Password<input type="password" name="password" required minlength="6"></label><label class="full">Address<textarea name="address" rows="3" placeholder="Street, city, state, postal code"><?= e($_POST['address'] ?? '') ?></textarea></label><label class="full">Profile picture <span class="label-hint">(optional, max 4MB)</span><input type="file" name="profile_pic" accept="image/jpeg,image/png,image/webp"></label><div class="full form-actions"><span></span><button class="button" type="submit">Create account</button></div></form><p class="auth-switch">Already have an account? <a href="<?= url('login.php') ?>">Sign in</a></p></div></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
