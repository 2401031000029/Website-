# VoltCart Electronics Store

VoltCart is a full electronics e-commerce demo built with procedural PHP, MySQL, plain HTML, CSS, and a small amount of vanilla JavaScript. It is designed to be easy to explain in a classroom and easy to run in XAMPP.

## Included

- Customer storefront: home, categories, product listing/search, product details, cart, checkout, simulated payment, wishlist, profile, order history, reorder, password change, login, registration, and simplified password recovery.
- Separate `/admin` area with one-time setup, dashboard totals, customer management, category management, product management with image uploads, and order status updates.
- Prepared statements for user-submitted values, password hashing, CSRF checks on forms, stock validation, and a transaction around order creation.
- `database.sql` creates all eight requested tables and inserts sample categories, products, and a `WELCOME10` coupon.

## XAMPP setup

1. Copy the `volt-cart` folder into your XAMPP `htdocs` folder.
2. Start Apache and MySQL from the XAMPP control panel.
3. Open `http://localhost/phpmyadmin`.
4. Import `database.sql`. The script creates the `volt_cart` database and seed data.
5. If your MySQL credentials are not the default XAMPP values, edit the values at the top of `config.php`, or set `DB_HOST`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`, and `DB_PORT`.
6. Open `http://localhost/volt-cart/admin/setup.php` once and create the first admin account.
7. Remove or protect `admin/setup.php` after creating the admin account.
8. Visit `http://localhost/volt-cart/` to use the storefront.

## Demo notes

- Checkout is intentionally simulated. No payment gateway or real card data is used.
- Forgot Password intentionally skips email verification because this is a classroom demo. A real production site should use expiring, emailed reset tokens.
- Uploaded product and profile images are stored in `uploads/` and `uploads/profile/`.
- The seeded coupon is `WELCOME10`.

## Suggested classroom walkthrough

1. Register a customer account.
2. Browse a category and add a product to the wishlist and cart.
3. Change the quantity above stock to see the cap message.
4. Use `WELCOME10` at checkout and place a simulated order.
5. Use the admin setup/login to update an order status or product stock.
