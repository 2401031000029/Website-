<?php
require_once __DIR__ . '/config.php';
$pageTitle = 'Shop products';
$categoryId = filter_input(INPUT_GET, 'category', FILTER_VALIDATE_INT) ?: 0;
$search = trim($_GET['q'] ?? '');
$categories = $conn->query("SELECT id, name FROM category WHERE status = 'show' ORDER BY name")->fetch_all(MYSQLI_ASSOC);
$sql = "SELECT p.*, c.name AS category_name FROM product p JOIN category c ON c.id = p.category_id WHERE p.status = 'show'";
$types = ''; $params = [];
if ($categoryId) { $sql .= ' AND p.category_id = ?'; $types .= 'i'; $params[] = $categoryId; }
if ($search !== '') { $sql .= ' AND (p.name LIKE ? OR p.description LIKE ?)'; $types .= 'ss'; $like = '%' . $search . '%'; $params[] = $like; $params[] = $like; }
$sql .= ' ORDER BY p.created_at DESC, p.id DESC';
$stmt = $conn->prepare($sql);
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
require __DIR__ . '/includes/header.php';
?>
<div class="page-intro compact"><p class="eyebrow">THE COLLECTION</p><h1><?= $search ? 'Search results' : 'All products' ?></h1><p><?= $search ? 'Showing matches for “' . e($search) . '”.' : 'Useful, well-made tech with a reason to exist.' ?></p></div>
<div class="filter-bar"><a class="<?= !$categoryId ? 'active' : '' ?>" href="<?= url('products.php') ?>">All</a><?php foreach ($categories as $category): ?><a class="<?= $categoryId === (int)$category['id'] ? 'active' : '' ?>" href="<?= url('products.php?category=' . (int)$category['id']) ?>"><?= e($category['name']) ?></a><?php endforeach; ?></div>
<?php if ($products): ?><div class="product-grid"><?php foreach ($products as $product) require __DIR__ . '/includes/product-card.php'; ?></div><?php else: ?><div class="empty-state"><span class="empty-icon">⌕</span><h2>No products found</h2><p>Try another search or browse the full collection.</p><a class="button button-small" href="<?= url('products.php') ?>">Reset filters</a></div><?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
