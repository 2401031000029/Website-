<?php
require_once __DIR__ . '/config.php';
$user = require_customer();
$userId = (int)$user['id'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $productId = (int)($_POST['product_id'] ?? 0);
    if (($_POST['action'] ?? '') === 'remove') {
        $stmt = $conn->prepare('DELETE FROM cart WHERE user_id = ? AND product_id = ?'); $stmt->bind_param('ii', $userId, $productId); $stmt->execute();
        flash('success', 'Item removed from your cart.');
    } else {
        $qty = max(1, (int)($_POST['qty'] ?? 1));
        $stockStmt = $conn->prepare('SELECT stock FROM product WHERE id = ? AND status = "show"'); $stockStmt->bind_param('i', $productId); $stockStmt->execute(); $stock = $stockStmt->get_result()->fetch_assoc();
        if (!$stock) { flash('error', 'That product is no longer available.'); }
        else {
            $allowed = min($qty, (int)$stock['stock']);
            $stmt = $conn->prepare('UPDATE cart SET qty = ? WHERE user_id = ? AND product_id = ?'); $stmt->bind_param('iii', $allowed, $userId, $productId); $stmt->execute();
            flash($allowed < $qty ? 'warning' : 'success', $allowed < $qty ? 'Quantity capped at the available stock.' : 'Cart updated.');
        }
    }
    redirect(url('cart.php'));
}
$stmt = $conn->prepare("SELECT c.product_id, c.qty, p.name, p.description, p.price, p.stock, p.image, cat.name AS category_name FROM cart c JOIN product p ON p.id = c.product_id JOIN category cat ON cat.id = p.category_id WHERE c.user_id = ? ORDER BY c.id DESC");
$stmt->bind_param('i', $userId); $stmt->execute(); $items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$subtotal = 0; foreach ($items as $item) $subtotal += (float)$item['price'] * (int)$item['qty'];
$pageTitle = 'Your cart';
require __DIR__ . '/includes/header.php';
?>
<div class="page-intro compact"><p class="eyebrow">READY WHEN YOU ARE</p><h1>Your cart.</h1><p><?= count($items) ? 'Review your picks before checkout.' : 'Your cart is waiting for its first upgrade.' ?></p></div>
<?php if ($items): ?><div class="cart-layout"><div class="cart-items"><?php foreach ($items as $item): ?><article class="cart-item"><img src="<?= e($item['image'] ? asset($item['image']) : asset('assets/product-placeholder.svg')) ?>" alt=""><div class="cart-item-main"><p class="eyebrow"><?= e($item['category_name']) ?></p><h3><?= e($item['name']) ?></h3><p class="muted"><?= money((float)$item['price']) ?> each · <?= (int)$item['stock'] ?> available</p><form method="post" class="cart-controls"><?= csrf_field() ?><input type="hidden" name="product_id" value="<?= (int)$item['product_id'] ?>"><input type="number" name="qty" min="1" max="<?= (int)$item['stock'] ?>" value="<?= (int)$item['qty'] ?>"><button class="button button-small button-outline" name="action" value="update">Update</button><button class="remove-button" name="action" value="remove">Remove</button></form></div><strong class="cart-line-total"><?= money((float)$item['price'] * (int)$item['qty']) ?></strong></article><?php endforeach; ?></div><aside class="summary-card"><p class="eyebrow">ORDER SUMMARY</p><div class="summary-row"><span>Subtotal</span><strong><?= money($subtotal) ?></strong></div><div class="summary-row"><span>Shipping</span><strong>Free</strong></div><div class="summary-total"><span>Total</span><strong><?= money($subtotal) ?></strong></div><a class="button full-button" href="<?= url('checkout.php') ?>">Proceed to checkout <span>→</span></a><p class="summary-note">Taxes and final total are confirmed at checkout.</p></aside></div><?php else: ?><div class="empty-state"><span class="empty-icon">+</span><h2>Nothing here yet.</h2><p>Add something useful and it will show up here.</p><a class="button button-small" href="<?= url('products.php') ?>">Start shopping</a></div><?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
