CREATE DATABASE IF NOT EXISTS volt_cart CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE volt_cart;

CREATE TABLE IF NOT EXISTS users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(30) DEFAULT NULL,
    address TEXT DEFAULT NULL,
    profile_pic VARCHAR(255) DEFAULT NULL,
    role ENUM('admin','customer') NOT NULL DEFAULT 'customer',
    status ENUM('active','blocked') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS category (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    image VARCHAR(255) DEFAULT NULL,
    status ENUM('show','hide') NOT NULL DEFAULT 'show',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS product (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    category_id INT UNSIGNED NOT NULL,
    name VARCHAR(160) NOT NULL,
    description TEXT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    stock INT UNSIGNED NOT NULL DEFAULT 0,
    image VARCHAR(255) DEFAULT NULL,
    status ENUM('show','hide') NOT NULL DEFAULT 'show',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_product_category FOREIGN KEY (category_id) REFERENCES category(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS orders (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    address TEXT NOT NULL,
    billing_address TEXT NOT NULL,
    coupon_code VARCHAR(60) DEFAULT NULL,
    discount_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    payment_status ENUM('pending','paid','refunded') NOT NULL DEFAULT 'pending',
    order_status ENUM('placed','shipped','delivered','cancelled') NOT NULL DEFAULT 'placed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_order_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS order_items (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id INT UNSIGNED NOT NULL,
    product_id INT UNSIGNED NOT NULL,
    qty INT UNSIGNED NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    CONSTRAINT fk_item_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    CONSTRAINT fk_item_product FOREIGN KEY (product_id) REFERENCES product(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS cart (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    product_id INT UNSIGNED NOT NULL,
    qty INT UNSIGNED NOT NULL DEFAULT 1,
    UNIQUE KEY unique_cart_item (user_id, product_id),
    CONSTRAINT fk_cart_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_cart_product FOREIGN KEY (product_id) REFERENCES product(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS wishlist (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    product_id INT UNSIGNED NOT NULL,
    UNIQUE KEY unique_wishlist_item (user_id, product_id),
    CONSTRAINT fk_wishlist_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_wishlist_product FOREIGN KEY (product_id) REFERENCES product(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS coupon (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(60) NOT NULL UNIQUE,
    discount_percent DECIMAL(5,2) NOT NULL,
    expiry_date DATE NOT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB;

INSERT INTO category (name, image, status) VALUES
('Audio', NULL, 'show'), ('Smart Home', NULL, 'show'), ('Computing', NULL, 'show'), ('Mobile', NULL, 'show')
ON DUPLICATE KEY UPDATE name = VALUES(name);

INSERT INTO product (category_id, name, description, price, stock, image, status)
SELECT c.id, 'Arc Wireless Headphones', 'Immersive noise cancellation, 40-hour battery life, and a comfortable fit for long listening sessions.', 129.00, 24, NULL, 'show' FROM category c WHERE c.name = 'Audio'
AND NOT EXISTS (SELECT 1 FROM product WHERE name = 'Arc Wireless Headphones');
INSERT INTO product (category_id, name, description, price, stock, image, status)
SELECT c.id, 'Halo Smart Speaker', 'Room-filling sound with voice control, multi-room pairing, and a privacy-first microphone switch.', 89.00, 18, NULL, 'show' FROM category c WHERE c.name = 'Smart Home'
AND NOT EXISTS (SELECT 1 FROM product WHERE name = 'Halo Smart Speaker');
INSERT INTO product (category_id, name, description, price, stock, image, status)
SELECT c.id, 'Keyline Mechanical Keyboard', 'Low-profile mechanical switches, warm backlight, and wireless connectivity for focused work.', 109.00, 11, NULL, 'show' FROM category c WHERE c.name = 'Computing'
AND NOT EXISTS (SELECT 1 FROM product WHERE name = 'Keyline Mechanical Keyboard');
INSERT INTO product (category_id, name, description, price, stock, image, status)
SELECT c.id, 'Pocket Power 20K', 'A slim high-capacity power bank with USB-C fast charging for commutes, travel, and daily backup.', 59.00, 32, NULL, 'show' FROM category c WHERE c.name = 'Mobile'
AND NOT EXISTS (SELECT 1 FROM product WHERE name = 'Pocket Power 20K');

INSERT INTO coupon (code, discount_percent, expiry_date, status) VALUES
('WELCOME10', 10.00, DATE_ADD(CURDATE(), INTERVAL 365 DAY), 'active')
ON DUPLICATE KEY UPDATE code = VALUES(code);
