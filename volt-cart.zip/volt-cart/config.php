<?php
declare(strict_types=1);

session_start();

$dbHost = getenv('DB_HOST') ?: '127.0.0.1';
$dbUser = getenv('DB_USER') ?: 'root';
$dbPass = getenv('DB_PASSWORD') ?: '';
$dbName = getenv('DB_NAME') ?: 'volt_cart';
$dbPort = (int) (getenv('DB_PORT') ?: 3306);

$conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName, $dbPort);
if ($conn->connect_errno) {
    http_response_code(500);
    exit('Database connection failed. Import database.sql and check config.php or your environment variables.');
}
$conn->set_charset('utf8mb4');

define('SITE_NAME', 'VoltCart');
define('SITE_TAGLINE', 'Smart tech. Better living.');
$documentRoot = str_replace('\\', '/', rtrim($_SERVER['DOCUMENT_ROOT'] ?? '', '/'));
$appRoot = str_replace('\\', '/', __DIR__);
define('BASE_PATH', $documentRoot && str_starts_with($appRoot, $documentRoot) ? substr($appRoot, strlen($documentRoot)) : '');

function e(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function redirect(string $url): never {
    header('Location: ' . $url);
    exit;
}

function flash(string $type, string $message): void {
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function get_flashes(): array {
    $flashes = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $flashes;
}

function money(float $amount): string {
    return '$' . number_format($amount, 2);
}

function url(string $path): string {
    return (BASE_PATH ? BASE_PATH : '') . '/' . ltrim($path, '/');
}

function asset(string $path): string {
    return url($path);
}

function upload_path(string $relative): string {
    return __DIR__ . '/' . ltrim($relative, '/');
}

function safe_upload(array $file, string $folder, string $prefix = 'image'): ?string {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return null;
    if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK || ($file['size'] ?? 0) > 4 * 1024 * 1024) return null;
    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if (!isset($allowed[$mime])) return null;
    $directory = upload_path($folder);
    if (!is_dir($directory)) mkdir($directory, 0755, true);
    $filename = $prefix . '-' . bin2hex(random_bytes(6)) . '.' . $allowed[$mime];
    if (!move_uploaded_file($file['tmp_name'], $directory . '/' . $filename)) return null;
    return trim($folder, '/') . '/' . $filename;
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}

function csrf_field(): string {
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(419);
        exit('Your form expired. Please go back and try again.');
    }
}

function customer(): ?array {
    global $conn;
    if (empty($_SESSION['customer_id'])) return null;
    $stmt = $conn->prepare('SELECT id, name, email, phone, address, profile_pic, status FROM users WHERE id = ? AND role = "customer" LIMIT 1');
    $stmt->bind_param('i', $_SESSION['customer_id']);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc() ?: null;
}

function cart_count(): int {
    global $conn;
    if (empty($_SESSION['customer_id'])) return 0;
    $stmt = $conn->prepare('SELECT COALESCE(SUM(qty), 0) AS total FROM cart WHERE user_id = ?');
    $stmt->bind_param('i', $_SESSION['customer_id']);
    $stmt->execute();
    return (int) ($stmt->get_result()->fetch_assoc()['total'] ?? 0);
}

function require_customer(): array {
    $user = customer();
    if (!$user) {
        flash('warning', 'Please sign in to continue.');
        redirect(url('login.php'));
    }
    if ($user['status'] !== 'active') {
        unset($_SESSION['customer_id']);
        flash('error', 'This account is blocked. Please contact support.');
        redirect(url('login.php'));
    }
    return $user;
}
