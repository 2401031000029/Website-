<?php
require_once __DIR__ . '/config.php';
$user = require_customer(); $userId = (int)$user['id'];
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect(url('cart.php'));
verify_csrf();
$billing = trim($_POST['billing_address'] ?? ''); $shipping = trim($_POST['shipping_address'] ?? ''); $couponCode = strtoupper(trim($_POST['coupon_code'] ?? ''));
if (!$billing || !$shipping) { flash('error', 'Both addresses are required.'); redirect(url('checkout.php')); }
$conn->begin_transaction();
try {
    $stmt = $conn->prepare("SELECT c.product_id, c.qty, p.name, p.price, p.stock FROM cart c JOIN product p ON p.id = c.product_id WHERE c.user_id = ? AND p.status = 'show' FOR UPDATE");
    $stmt->bind_param('i', $userId); $stmt->execute(); $items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    if (!$items) throw new Exception('Your cart is empty.');
    $subtotal = 0; foreach ($items as $item) { if ((int)$item['qty'] > (int)$item['stock']) throw new Exception('Stock changed for ' . $item['name'] . '. Please update your cart.'); $subtotal += (float)$item['price'] * (int)$item['qty']; }
    $discount = 0; $validCode = null;
    if ($couponCode) { $stmt = $conn->prepare('SELECT code, discount_percent FROM coupon WHERE code = ? AND status = "active" AND expiry_date >= CURDATE() LIMIT 1'); $stmt->bind_param('s', $couponCode); $stmt->execute(); $coupon = $stmt->get_result()->fetch_assoc(); if ($coupon) { $discount = round($subtotal * ((float)$coupon['discount_percent'] / 100), 2); $validCode = $coupon['code']; } else throw new Exception('That coupon is invalid or expired.'); }
    $total = max(0, $subtotal - $discount);
    $stmt = $conn->prepare("INSERT INTO orders (user_id, total_amount, address, billing_address, coupon_code, discount_amount, payment_status, order_status) VALUES (?, ?, ?, ?, ?, ?, 'paid', 'placed')");
    $stmt->bind_param('idsssd', $userId, $total, $shipping, $billing, $validCode, $discount); $stmt->execute(); $orderId = $conn->insert_id;
    $itemStmt = $conn->prepare('INSERT INTO order_items (order_id, product_id, qty, price) VALUES (?, ?, ?, ?)');
    $stockStmt = $conn->prepare('UPDATE product SET stock = stock - ? WHERE id = ?');
    foreach ($items as $item) { $productId = (int)$item['product_id']; $qty = (int)$item['qty']; $price = (float)$item['price']; $itemStmt->bind_param('iiid', $orderId, $productId, $qty, $price); $itemStmt->execute(); $stockStmt->bind_param('ii', $qty, $productId); $stockStmt->execute(); }
    $clear = $conn->prepare('DELETE FROM cart WHERE user_id = ?'); $clear->bind_param('i', $userId); $clear->execute();
    $conn->commit(); redirect(url('payment-success.php?order=' . $orderId));
} catch (Throwable $error) { $conn->rollback(); flash('error', $error->getMessage()); redirect(url('checkout.php')); }
