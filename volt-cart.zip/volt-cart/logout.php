<?php
require_once __DIR__ . '/config.php';
unset($_SESSION['customer_id']);
flash('success', 'You have been signed out.');
redirect(url('index.php'));
