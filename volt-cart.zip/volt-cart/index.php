<?php
require_once __DIR__ . '/config.php';
$pageTitle = 'Everyday tech, upgraded';
$categories = $conn->query("SELECT * FROM category WHERE status = 'show' ORDER BY id LIMIT 4")->fetch_all(MYSQLI_ASSOC);
$products = $conn->query("SELECT p.*, c.name AS category_name FROM product p JOIN category c ON c.id = p.category_id WHERE p.status = 'show' ORDER BY p.created_at DESC, p.id DESC LIMIT 4")->fetch_all(MYSQLI_ASSOC);
require __DIR__ . '/includes/header.php';
?>
<section class="hero">
    <div class="hero-copy"><p class="eyebrow">THE EVERYDAY UPGRADE</p><h1>Technology that<br><span>keeps up.</span></h1><p class="hero-text">Curated electronics for better work, sharper play, and calmer spaces. No clutter. Just the good stuff.</p><div class="hero-actions"><a class="button" href="<?= url('products.php') ?>">Shop the collection <span>→</span></a><a class="text-link" href="<?= url('categories.php') ?>">Browse categories</a></div></div>
    <div class="hero-art"><div class="orbit orbit-one"></div><div class="orbit orbit-two"></div><div class="device-orb"><span>V</span></div><div class="hero-chip chip-one">20K<br><small>items shipped</small></div><div class="hero-chip chip-two">4.9/5<br><small>customer rating</small></div></div>
</section>
<section class="section"><div class="section-heading"><div><p class="eyebrow">FIND YOUR FREQUENCY</p><h2>Shop by category</h2></div><a class="text-link" href="<?= url('categories.php') ?>">View all →</a></div><div class="category-grid">
<?php foreach ($categories as $category): ?><a class="category-card" href="<?= url('products.php?category=' . (int)$category['id']) ?>"><span class="category-icon"><?= e(strtoupper(substr($category['name'], 0, 1))) ?></span><span><strong><?= e($category['name']) ?></strong><small>Explore collection</small></span><span class="arrow">↗</span></a><?php endforeach; ?>
</div></section>
<section class="section section-last"><div class="section-heading"><div><p class="eyebrow">HANDPICKED FOR YOU</p><h2>Featured drops</h2></div><a class="text-link" href="<?= url('products.php') ?>">See everything →</a></div><div class="product-grid"><?php foreach ($products as $product) require __DIR__ . '/includes/product-card.php'; ?></div></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
