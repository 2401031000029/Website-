<?php
require_once __DIR__ . '/config.php';
$pageTitle = 'Categories';
$categories = $conn->query("SELECT c.*, COUNT(p.id) AS product_count FROM category c LEFT JOIN product p ON p.category_id = c.id AND p.status = 'show' WHERE c.status = 'show' GROUP BY c.id ORDER BY c.name")->fetch_all(MYSQLI_ASSOC);
require __DIR__ . '/includes/header.php';
?>
<div class="page-intro"><p class="eyebrow">EXPLORE THE RANGE</p><h1>Find your next favorite.</h1><p>From desk essentials to weekend audio, start with the category that fits your world.</p></div>
<div class="category-grid category-grid-large"><?php foreach ($categories as $category): ?><a class="category-card" href="<?= url('products.php?category=' . (int)$category['id']) ?>"><span class="category-icon"><?= e(strtoupper(substr($category['name'], 0, 1))) ?></span><span><strong><?= e($category['name']) ?></strong><small><?= (int)$category['product_count'] ?> products</small></span><span class="arrow">↗</span></a><?php endforeach; ?></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
